# Implementation Notes & Troubleshooting 🔧

## What Was Changed

### 1. TypeScript Component (products-list.ts)

#### Added Imports:
```typescript
import { FormsModule } from '@angular/forms';  // For ngClass binding
```

#### Added to Imports Array:
```typescript
imports: [CommonModule, RouterModule, FormsModule, ProductDetails]
```

#### Added New Signal:
```typescript
protected wishlist = signal<Set<string>>(new Set());
```
- Stores product IDs of wishlist items
- Uses Signal API for reactivity
- Persists during session

#### Added Helper Methods:

**1. `getDiscountedPrice(price: number, discount: number): number`**
```typescript
// Calculates discounted price with rounding
// Example: getDiscountedPrice(1000, 20) = 800
```

**2. `getStarArray(rating: number): number[]`**
```typescript
// Returns array for star display
// 1 = full star, 0.5 = half star, 0 = empty star
// Example: getStarArray(3.5) = [1, 1, 1, 0.5, 0]
```

**3. `toggleWishlist(productId: string, event: Event): void`**
```typescript
// Adds/removes product from wishlist
// Stops event propagation to prevent card click
```

**4. `isInWishlist(productId: string): boolean`**
```typescript
// Checks if product is in wishlist
// Used for styling active button state
```

**5. `getStockStatus(stock: number): { label: string; class: string }`**
```typescript
// Returns status object for display and styling
// 0 = "Out of Stock" / < 5 = "Only X left!" / else = "In Stock"
```

---

### 2. HTML Template (products-list.html)

#### Badges Section:
```html
<div class="product-badges">
  @if (prod.isFeatured) {
    <span class="badge badge-featured">✨ Featured</span>
  }
  @if (prod.discount > 0) {
    <span class="badge badge-discount">{{ prod.discount }}% OFF</span>
  }
</div>
```

#### Wishlist Button:
```html
<button class="wishlist-btn" 
  [class.active]="isInWishlist(prod._id)"
  (click)="toggleWishlist(prod._id, $event)"
  [title]="isInWishlist(prod._id) ? 'Remove from Wishlist' : 'Add to Wishlist'">
  ❤️
</button>
```

#### Brand Name:
```html
<p class="product-brand">{{ prod.brand }}</p>
```

#### Star Rating:
```html
<div class="product-rating mb-2">
  <div class="stars">
    @for (star of getStarArray(prod.rating); track $index) {
      @if (star === 1) {
        <span class="star full">★</span>
      }
      @if (star === 0.5) {
        <span class="star half">★</span>
      }
      @if (star === 0) {
        <span class="star empty">★</span>
      }
    }
  </div>
  <span class="review-count">({{ prod.numReviews }} reviews)</span>
</div>
```

#### Pricing with Discount:
```html
<div class="price-section mb-2">
  @if (prod.discount > 0) {
    <div class="price-row">
      <span class="original-price">₹ {{ prod.price }}</span>
      <span class="discounted-price fw-bold">₹ {{ getDiscountedPrice(prod.price, prod.discount) }}</span>
    </div>
  } @else {
    <p class="current-price fw-bold text-danger mb-0">₹ {{ prod.price }}</p>
  }
</div>
```

#### Stock Status:
```html
<p class="stock-status" 
  [ngClass]="'stock-' + getStockStatus(prod.stock).class">
  {{ getStockStatus(prod.stock).label }}
</p>
```

#### Out of Stock Overlay:
```html
@if (prod.stock === 0) {
  <div class="out-of-stock-overlay">Out of Stock</div>
}
```

---

### 3. CSS Enhancements (products-list.css)

#### New CSS Classes Added:

**Badges:**
- `.product-badges` - Container for badge positioning
- `.badge` - Base badge styling
- `.badge-featured` - Purple gradient featured badge
- `.badge-discount` - Red animated discount badge
- `@keyframes pulse` - Pulsing animation for discount

**Wishlist:**
- `.wishlist-btn` - Circular button styling
- `.wishlist-btn:hover` - Hover state
- `.wishlist-btn.active` - Active/added state

**Stock & Overlay:**
- `.out-of-stock-overlay` - Overlay on image
- `.stock-status` - Base status styling
- `.stock-available` - Green status
- `.stock-low` - Orange status
- `.stock-out` - Red status

**Brand & Typography:**
- `.product-brand` - Uppercase brand name
- `.product-rating` - Star container
- `.stars` - Star flex container
- `.star.full`, `.star.half`, `.star.empty` - Individual star colors
- `.review-count` - Review link styling

**Pricing:**
- `.price-section` - Container
- `.price-row` - Row for both prices
- `.original-price` - Strikethrough original
- `.discounted-price` - Bold discount price
- `.current-price` - Non-discount price

#### Modified CSS Classes:
- `.product-card` - Added position: relative, height: 100%
- `.product-image` - Added position: relative for overlay
- `.product-info` - Existing, now contains more content

---

## Common Questions & Answers

### Q: How do I update wishlist when the user logs out?
**A:** Clear the wishlist signal:
```typescript
logout() {
  this.wishlist.set(new Set());  // Clear wishlist on logout
}
```

### Q: How do I persist wishlist data?
**A:** Save to localStorage:
```typescript
// Save on toggle
toggleWishlist(productId: string, event: Event): void {
  // ... existing code ...
  localStorage.setItem('wishlist', JSON.stringify(Array.from(this.wishlist())));
}

// Load on init
ngOnInit(): void {
  const saved = localStorage.getItem('wishlist');
  if (saved) {
    this.wishlist.set(new Set(JSON.parse(saved)));
  }
  this.loadProducts();
}
```

### Q: Can I customize the star icon?
**A:** Yes, replace the ★ character with any emoji:
```html
<!-- Use different characters -->
<span class="star full">⭐</span>  <!-- Emoji star -->
<span class="star full">✨</span>  <!-- Sparkle -->
<span class="star full">◉</span>   <!-- Circle -->
```

### Q: How do I make the review count clickable?
**A:** Add a click handler:
```html
<span class="review-count" (click)="scrollToReviews(prod._id)">
  ({{ prod.numReviews }} reviews)
</span>
```

```typescript
protected scrollToReviews(productId: string): void {
  // Scroll to reviews section in product details
  const element = document.getElementById(`reviews-${productId}`);
  element?.scrollIntoView({ behavior: 'smooth' });
}
```

### Q: How do I change the discount badge color?
**A:** Modify the CSS:
```css
.badge-discount {
  background: #d32f2f;  /* Change this */
  color: white;
  box-shadow: 0 2px 4px rgba(211, 47, 47, 0.3);
}
```

### Q: Can I add more badges (e.g., "New", "Hot")?
**A:** Yes, add to your ProductData model and template:
```typescript
// In product-data.ts
export class ProductData {
  // ... existing fields ...
  isNew: boolean;
  isHot: boolean;
}
```

```html
@if (prod.isNew) {
  <span class="badge badge-new">🆕 New</span>
}
@if (prod.isHot) {
  <span class="badge badge-hot">🔥 Hot</span>
}
```

### Q: How do I track wishlist analytics?
**A:** Log events when toggling:
```typescript
toggleWishlist(productId: string, event: Event): void {
  event.stopPropagation();
  const updatedWishlist = new Set(this.wishlist());
  const isAdding = !updatedWishlist.has(productId);
  
  // Track event
  console.log(isAdding ? 'Added to wishlist' : 'Removed from wishlist', productId);
  
  // Send to analytics service
  this.analytics.track({
    event: isAdding ? 'wishlist_add' : 'wishlist_remove',
    product_id: productId,
    timestamp: new Date()
  });
  
  // Update state
  if (isAdding) {
    updatedWishlist.add(productId);
  } else {
    updatedWishlist.delete(productId);
  }
  this.wishlist.set(updatedWishlist);
}
```

---

## Troubleshooting

### Issue: Stars not displaying correctly

**Symptoms:** Stars showing as boxes or not appearing

**Solution:**
1. Check if `getStarArray()` method exists
2. Verify rating value is numeric (0-5)
3. Check CSS color values for `.star` classes
4. Make sure star unicode character (★) is saved correctly

```typescript
// Debug: Log star array
console.log('Stars:', this.getStarArray(4.5)); // Should output [1, 1, 1, 1, 0.5, 0]
```

### Issue: Wishlist button not toggling

**Symptoms:** Button click doesn't change appearance

**Solution:**
1. Check if `toggleWishlist()` method is being called
2. Verify `[class.active]` binding is correct
3. Check CSS for `.wishlist-btn.active` styling
4. Open DevTools and check element classes

```typescript
// Debug: Check wishlist state
console.log('Wishlist:', Array.from(this.wishlist()));
console.log('Is in wishlist:', this.isInWishlist('product-id'));
```

### Issue: Discount price not calculating

**Symptoms:** Prices showing incorrectly or not updating

**Solution:**
1. Verify `prod.discount` is a number (0-100)
2. Check `prod.price` is not null/undefined
3. Test `getDiscountedPrice()` method manually
4. Verify conditional `@if (prod.discount > 0)` is true

```typescript
// Debug: Test price calculation
console.log('Original:', 1000);
console.log('Discount %:', 20);
console.log('Result:', this.getDiscountedPrice(1000, 20)); // Should be 800
```

### Issue: Stock status colors not showing

**Symptoms:** Status text appears but color is wrong

**Solution:**
1. Verify `getStockStatus()` method returns correct class names
2. Check CSS for `.stock-available`, `.stock-low`, `.stock-out`
3. Ensure `[ngClass]` binding is properly formatted
4. Check if Bootstrap is overriding styles

```html
<!-- Debug: Add temporary text -->
<p>{{ getStockStatus(prod.stock).class }}</p> <!-- Should show class name -->
```

### Issue: Badge animation too slow/fast

**Symptoms:** Pulse animation not noticeable or too jarring

**Solution:**
Adjust animation timing in CSS:
```css
.badge-discount {
  animation: pulse 2s ease-in-out infinite;  /* Change 2s to desired duration */
}

@keyframes pulse {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.05);  /* Change 1.05 for more/less zoom */
  }
}
```

### Issue: Mobile layout breaking

**Symptoms:** Text overflowing, buttons stacking incorrectly

**Solution:**
1. Check responsive breakpoints in CSS
2. Verify media queries are correct
3. Test on actual mobile devices
4. Check Bootstrap grid classes (col-12, col-sm-6, etc.)

```css
/* Add more aggressive mobile breakpoints if needed */
@media (max-width: 360px) {
  .product-card {
    /* Additional adjustments */
  }
}
```

### Issue: Out of stock overlay not appearing

**Symptoms:** Out of stock products showing normally

**Solution:**
1. Check if `prod.stock === 0` is being evaluated
2. Verify CSS for `.out-of-stock-overlay`
3. Check z-index stacking context
4. Make sure `.product-image` has `position: relative`

```typescript
// Debug: Log stock value
console.log('Stock:', prod.stock, typeof prod.stock); // Should be number 0
```

---

## Performance Optimization Tips

### 1. LazyLoad Product Images
```html
<img [src]="prod.images[0]" 
     loading="lazy"
     alt="{{ prod.name }}">
```

### 2. Limit Star Array Regeneration
```typescript
// Memoize results
private starCache = new Map<number, number[]>();

protected getStarArray(rating: number): number[] {
  if (!this.starCache.has(rating)) {
    const stars = [];
    const fullStars = Math.floor(rating);
    for (let i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.push(1);
      } else if (i === fullStars && rating % 1 !== 0) {
        stars.push(0.5);
      } else {
        stars.push(0);
      }
    }
    this.starCache.set(rating, stars);
  }
  return this.starCache.get(rating)!;
}
```

### 3. Reduce DOM Updates for Wishlist
```typescript
// Use trackBy for better performance
protected trackByProductId(index: number, prod: ProductData): string {
  return prod._id;
}
```

### 4. Debounce Wishlist Updates
```typescript
private wishlistSubject = new Subject<string>();

ngOnInit() {
  this.wishlistSubject.pipe(
    debounceTime(300),
    distinctUntilChanged()
  ).subscribe(productId => {
    // Save to localStorage or API
  });
}

toggleWishlist(productId: string, event: Event): void {
  event.stopPropagation();
  // ... toggle logic ...
  this.wishlistSubject.next(productId);
}
```

---

## Browser Compatibility

| Feature | Chrome | Firefox | Safari | Edge | Mobile |
|---------|--------|---------|--------|------|--------|
| CSS Animations | ✓ | ✓ | ✓ | ✓ | ✓ |
| CSS Gradients | ✓ | ✓ | ✓ | ✓ | ✓ |
| CSS Transforms | ✓ | ✓ | ✓ | ✓ | ✓ |
| CSS Box Shadow | ✓ | ✓ | ✓ | ✓ | ✓ |
| Signal API | ✓ | ✓ | ✓ | ✓ | ✓ |
| Set Object | ✓ | ✓ | ✓ | ✓ | ✓ |

---

## Next Steps to Enhance Further

1. **Add Quick View Modal**
   - Show product details without navigation
   - Implement with ng-bootstrap or custom modal

2. **Implement Real Wishlist Persistence**
   - Save to localStorage or backend
   - Sync across devices when user logged in

3. **Add Product Reviews Section**
   - Display average rating
   - Show review breakdown (5★, 4★, etc.)
   - Add "Write Review" button

4. **Create "Add to Cart" Toast**
   - Show notification when product added
   - Allow quick checkout

5. **Build Sidebar Filters**
   - Filter by price range
   - Filter by rating
   - Filter by brand
   - Filter by category

6. **Add Product Comparison**
   - Compare specifications
   - Compare prices
   - Side-by-side features

---

## Support & Resources

- **Angular Docs**: https://angular.io/docs
- **Bootstrap Grid**: https://getbootstrap.com/docs/5.0/layout/grid/
- **CSS Animations**: https://developer.mozilla.org/en-US/docs/Web/CSS/animation
- **Angular Signals**: https://angular.io/guide/signals

---

## Version Info

- **Angular**: 20.3.6
- **Bootstrap**: 5.x (assumed from CSS classes)
- **TypeScript**: Latest (from Angular 20)
- **Created**: 2024

---

Generated for: Bajaj E-Commerce Application