# API-Aligned Routing Configuration

This document outlines how the Angular routing has been configured to align with the provided API endpoints structure.

## Routing Structure Overview

### Auth & Users Routes (API endpoints 1-4)
- `POST /api/auth/register` → `/auth/register` (RegisterComponent)
- `POST /api/auth/login` → `/auth/login` (LoginComponent)  
- `GET /api/auth/me` → `/auth/me` (ProfileComponent) - requires authentication
- `GET /api/users` → `/admin/users` (UsersListComponent) - requires admin role

### Categories Routes (API endpoints 5-8)
- `GET /api/categories` → `/categories` (CategoriesList)
- `POST /api/categories` → `/admin/categories/new` (RegisterCategory) - admin only
- `PUT /api/categories/:id` → `/admin/categories/:id/edit` (RegisterCategory) - admin only
- `DELETE /api/categories/:id` → handled via admin interface - admin only
- Individual category view → `/categories/:id` (CategoryDetails)

### Products Routes (API endpoints 9-13)
- `GET /api/products` → `/products` (ProductsList)
- `GET /api/products/:id` → `/products/:id` (ProductDetails)
- `POST /api/products` → `/admin/products/new` (RegisterProduct) - admin only
- `PUT /api/products/:id` → `/admin/products/:id/edit` (RegisterProduct) - admin only
- `DELETE /api/products/:id` → handled via admin interface - admin only
- Products by category → `/products/category/:categoryId` (ProductsList)

### Orders Routes (API endpoints 14-18)
- `POST /api/orders` → handled via `/checkout` (CheckoutComponent) - customer/admin
- `GET /api/orders` → `/admin/orders` (OrderHistoryComponent) - admin only
- `GET /api/orders/my` → `/orders` (OrderHistoryComponent) - customer only
- `GET /api/orders/:id` → `/orders/:id` (OrderHistoryComponent) - customer/admin
- `PUT /api/orders/:id/status` → handled via admin interface - admin only

### Cart Routes (API endpoints 19-21)
- `POST /api/cart/add` → handled via product pages and cart component
- `GET /api/cart` → `/cart` (CartComponent) - requires authentication
- `DELETE /api/cart/:id` → handled via cart component

### Reviews Routes (API endpoints 22-23)  
- `POST /api/reviews/:productId` → handled within product details page
- `GET /api/reviews/:productId` → handled within product details page at `/products/:productId`

### Admin Dashboard (API endpoint 24)
- `GET /api/admin/summary` → `/admin/dashboard` (AdminDashboardComponent) - admin only

## Guard Implementation

### AuthGuard
- Protects routes that require user authentication
- Redirects unauthenticated users to `/auth/login`
- Stores attempted URL for post-login redirect

### AdminGuard  
- Protects admin-only routes
- Requires both authentication and admin role
- Redirects non-admin users to home page
- Redirects unauthenticated users to login

## Key Features

### Route Protection
- Customer routes: Protected by `AuthGuard`
- Admin routes: Protected by `AdminGuard` 
- Public routes: No guards required

### Lazy Loading
- Most feature components are lazy-loaded for better performance
- Uses dynamic imports with `loadComponent`

### Route Data
- Admin routes include `data: { adminView: true }` for component logic
- Helps components determine their context and behavior

### Redirects
- `/profile` redirects to `/auth/me`
- `/orders/my` redirects to `/orders` 
- `/admin` redirects to `/admin/dashboard`
- Review routes redirect to product details

### Fallback
- Wildcard route `**` redirects to home page for unmatched routes

## Component Structure

### New Components Created
1. **AdminDashboardComponent** (`/admin/dashboard`)
   - Platform metrics and overview
   - Quick action buttons
   - Recent orders and top products display

2. **UsersListComponent** (`/admin/users`)
   - User management interface
   - Search and filter functionality
   - User role and status management

### Existing Components Utilized
- **Home**: Landing page
- **LoginComponent**: User authentication
- **RegisterComponent**: User registration  
- **CategoriesList**: Category browsing
- **ProductsList**: Product browsing with filters
- **ProductDetails**: Individual product view
- **CartComponent**: Shopping cart management
- **CheckoutComponent**: Order creation process
- **OrderHistoryComponent**: Order viewing and management
- **ProfileComponent**: User profile management

## API Integration Points

The routing structure is designed to work seamlessly with the provided API:

1. **Public Routes**: No authentication required, map to public API endpoints
2. **Authenticated Routes**: Require login, map to user-specific API endpoints  
3. **Admin Routes**: Require admin role, map to admin-only API endpoints
4. **REST Pattern**: URLs follow RESTful conventions matching the API structure

## Usage Examples

### Customer Journey
1. `/` → Home page
2. `/auth/register` → Account creation
3. `/auth/login` → Authentication
4. `/categories` → Browse categories
5. `/products` → Browse products
6. `/products/:id` → View product details
7. `/cart` → Review cart items
8. `/checkout` → Place order
9. `/orders` → View order history

### Admin Journey  
1. `/auth/login` → Admin authentication
2. `/admin/dashboard` → Platform overview
3. `/admin/products/new` → Add new product
4. `/admin/categories/new` → Add new category
5. `/admin/orders` → Manage all orders
6. `/admin/users` → Manage users

This routing configuration provides a complete foundation for the e-commerce application that aligns perfectly with the provided API structure while maintaining Angular best practices for routing, guards, and lazy loading.