# Backend Integration Guide

## Overview
This application has been configured to fetch all product data from a backend API instead of using mock data. The changes ensure robust error handling and seamless integration with your backend services.

## Key Changes Made

### 1. Environment Configuration
- Created `src/environments/environment.ts` for development
- Created `src/environments/environment.prod.ts` for production
- Backend API URL is now configurable per environment

### 2. Products API Service Updates
- **Default Mode**: Now uses backend API by default (`useMockData: false`)
- **Error Handling**: Comprehensive error handling for all API calls
- **Environment Integration**: Uses environment variables for API base URL
- **Graceful Fallbacks**: Provides user-friendly error messages

### 3. Component Error Handling
Updated all product-related components to handle API errors:
- `ProductDetails` component - Shows error messages with retry functionality
- `ProductsList` component - Error states with retry options
- `Home` component - Error handling for featured products and categories

### 4. Angular Configuration
- Updated `angular.json` to properly replace environment files during build
- Production builds will use `environment.prod.ts`

## Backend API Endpoints Expected

Your backend should provide these endpoints:

### Products
- `GET /api/products` - Get all products
- `GET /api/products/{id}` - Get product details
- `GET /api/products?categoryId={id}` - Get products by category
- `GET /api/products?categorySlug={slug}` - Get products by category slug
- `GET /api/products?featured=true` - Get featured products
- `GET /api/products?search={query}` - Search products
- `GET /api/products?minPrice={min}&maxPrice={max}` - Filter by price range

### Expected Response Format

#### Product List Response
```json
{
  "success": true,
  "total": 100,
  "page": 1,
  "pages": 10,
  "count": 10,
  "data": [
    {
      "_id": "prod_001",
      "name": "Product Name",
      "sku": "SKU-001",
      "description": "Product description",
      "price": 1000,
      "discount": 10,
      "categoryId": {
        "_id": "cat_001",
        "name": "Category Name",
        "slug": "category-slug"
      },
      "brand": "Brand Name",
      "images": ["image1.jpg", "image2.jpg"],
      "stock": 50,
      "rating": 4.5,
      "numReviews": 100,
      "attributes": {
        "color": "Red",
        "material": "Cotton",
        "warranty": "1 Year"
      },
      "isFeatured": true,
      "createdAt": "2024-01-01T00:00:00Z",
      "updatedAt": "2024-01-01T00:00:00Z"
    }
  ]
}
```

#### Product Details Response
```json
{
  "success": true,
  "data": {
    "_id": "prod_001",
    // ... same product structure as above
  }
}
```

## Configuration

### Development Environment
Update `src/environments/environment.ts`:
```typescript
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:9090/api', // Your dev API URL
  useMockData: false // Set to true if you want to use mock data temporarily
};
```

### Production Environment
Update `src/environments/environment.prod.ts`:
```typescript
export const environment = {
  production: true,
  apiBaseUrl: 'https://your-production-api.com/api', // Your production API URL
  useMockData: false
};
```

## Testing Backend Integration

### 1. Start Your Backend
Ensure your backend API is running on the configured URL (default: `http://localhost:9090`)

### 2. Run the Application
```bash
ng serve
```

### 3. Verify Functionality
- Browse to products list page
- Check individual product details
- Test category filtering
- Verify search functionality
- Check featured products on home page

### 4. Test Error Handling
- Stop your backend server temporarily
- Try to load products - should show error messages with retry options
- Restart backend and use retry buttons

## Switching Back to Mock Data (if needed)

If you need to temporarily use mock data:

1. Update environment file:
```typescript
export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:9090/api',
  useMockData: true // Switch to mock data
};
```

2. Restart the development server

## Error Handling Features

- **Network Errors**: Clear messages when backend is unreachable
- **Server Errors**: Proper handling of 4xx/5xx responses
- **Empty Responses**: Graceful handling of empty product lists
- **Loading States**: Proper loading indicators during API calls
- **Retry Functionality**: Users can retry failed requests

## Next Steps

1. Ensure your backend implements all required endpoints
2. Test thoroughly with your actual backend API
3. Update the production API URL in `environment.prod.ts`
4. Consider implementing additional error logging if needed
5. Add any custom headers or authentication tokens as required

## Support

If you encounter issues:
1. Check browser console for detailed error messages
2. Verify backend API is running and accessible
3. Ensure API responses match the expected format
4. Check network requests in browser developer tools