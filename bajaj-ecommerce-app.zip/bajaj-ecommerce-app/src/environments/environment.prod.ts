// Production environment configuration
export const environment = {
  production: true,
  apiBaseUrl: 'https://your-production-api.com/api', // Replace with your actual production API URL
  useMockData: false
};