import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-register-product',
  imports: [],
  templateUrl: './register-product.html',
  styleUrl: './register-product.css',
})
export class RegisterProduct {

}
