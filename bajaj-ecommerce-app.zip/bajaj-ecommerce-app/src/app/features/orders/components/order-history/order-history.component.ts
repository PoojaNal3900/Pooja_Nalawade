import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { OrderService } from '../../../../shared/services/order.service';
import { Order } from '../../../../shared/models/order';

@Component({
  selector: 'app-order-history',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit {
  orders: Order[] = [];
  isLoading = true;
  orderPlaced = false;
  isAdminView = false;
  statusMessage = '';
  errorMessage = '';
  updatingOrders: Record<string, boolean> = {};

  constructor(
    private route: ActivatedRoute,
    private orderService: OrderService
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.orderPlaced = params['orderPlaced'] === 'true';
    });

    this.route.data.subscribe(data => {
      this.isAdminView = data['adminView'] === true;
      this.loadOrders();
    });
  }

  approveOrder(order: Order): void {
    this.statusMessage = '';
    this.errorMessage = '';
    this.updatingOrders[order._id] = true;

    this.orderService.updateOrderStatus(order._id, 'Confirmed').subscribe({
      next: updatedOrder => {
        this.updatingOrders[order._id] = false;
        this.statusMessage = `Order ${updatedOrder._id} approved successfully.`;
        this.orders = this.orders.map(existing => existing._id === updatedOrder._id ? updatedOrder : existing);
      },
      error: error => {
        this.updatingOrders[order._id] = false;
        this.errorMessage = error.message || 'Unable to approve order. Please try again later.';
      }
    });
  }

  isUpdating(orderId: string): boolean {
    return this.updatingOrders[orderId] === true;
  }

  private loadOrders(): void {
    this.isLoading = true;
    const source$ = this.isAdminView ? this.orderService.getAdminOrders() : this.orderService.getUserOrders();

    source$.subscribe({
      next: (orders) => {
        this.orders = orders;
        this.isLoading = false;
        console.log('Loaded orders:', orders);
      },
      error: (error) => {
        console.error('Error loading orders:', error);
        this.isLoading = false;
        this.orders = [];
      }
    });
  }

  getStatusClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'pending': return 'badge bg-warning';
      case 'confirmed': return 'badge bg-info';
      case 'processing': return 'badge bg-primary';
      case 'shipped': return 'badge bg-secondary';
      case 'delivered': return 'badge bg-success';
      case 'cancelled': return 'badge bg-danger';
      default: return 'badge bg-secondary';
    }
  }
}