import { Injectable, signal } from '@angular/core';

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface ToastMessage {
  id: number;
  type: ToastType;
  message: string;
  title?: string;
  duration: number;
}

@Injectable({
  providedIn: 'root'
})
export class ToastService {
  private toastsSignal = signal<ToastMessage[]>([]);
  private timeouts = new Map<number, ReturnType<typeof setTimeout>>();
  private counter = 0;

  readonly toasts = this.toastsSignal.asReadonly();

  show(type: ToastType, message: string, options?: { title?: string; duration?: number }): void {
    const duration = options?.duration ?? 4000;
    const toast: ToastMessage = {
      id: ++this.counter,
      type,
      message,
      title: options?.title,
      duration
    };

    this.toastsSignal.update(list => [...list, toast]);

    const timeout = setTimeout(() => this.remove(toast.id), duration);
    this.timeouts.set(toast.id, timeout);
  }

  success(message: string, options?: { title?: string; duration?: number }): void {
    this.show('success', message, options);
  }

  error(message: string, options?: { title?: string; duration?: number }): void {
    this.show('error', message, options);
  }

  info(message: string, options?: { title?: string; duration?: number }): void {
    this.show('info', message, options);
  }

  warning(message: string, options?: { title?: string; duration?: number }): void {
    this.show('warning', message, options);
  }

  remove(id: number): void {
    const timeout = this.timeouts.get(id);
    if (timeout) {
      clearTimeout(timeout);
      this.timeouts.delete(id);
    }

    this.toastsSignal.update(list => list.filter(item => item.id !== id));
  }

  clear(): void {
    this.timeouts.forEach(timeout => clearTimeout(timeout));
    this.timeouts.clear();
    this.toastsSignal.set([]);
  }
}
