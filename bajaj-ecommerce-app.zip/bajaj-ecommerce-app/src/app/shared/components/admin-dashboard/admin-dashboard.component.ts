import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

interface AdminSummary {
  totalUsers: number;
  totalOrders: number;
  totalProducts: number;
  totalCategories: number;
  totalSales: number;
  recentOrders: any[];
  topProducts: any[];
}

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="admin-dashboard">
      <div class="dashboard-header">
        <h1>Admin Dashboard</h1>
        <p>Platform Overview & Metrics</p>
      </div>

      <div class="metrics-grid">
        <div class="metric-card">
          <div class="metric-icon">👥</div>
          <div class="metric-content">
            <h3>{{ summary.totalUsers }}</h3>
            <p>Total Users</p>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon">📦</div>
          <div class="metric-content">
            <h3>{{ summary.totalOrders }}</h3>
            <p>Total Orders</p>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon">🛍️</div>
          <div class="metric-content">
            <h3>{{ summary.totalProducts }}</h3>
            <p>Total Products</p>
          </div>
        </div>

        <div class="metric-card">
          <div class="metric-icon">📂</div>
          <div class="metric-content">
            <h3>{{ summary.totalCategories }}</h3>
            <p>Categories</p>
          </div>
        </div>

        <div class="metric-card sales">
          <div class="metric-icon">💰</div>
          <div class="metric-content">
            <h3>\${{ summary.totalSales | number:'1.2-2' }}</h3>
            <p>Total Sales</p>
          </div>
        </div>
      </div>

      <div class="dashboard-actions">
        <div class="action-section">
          <h2>Quick Actions</h2>
          <div class="action-buttons">
            <a routerLink="/admin/products/new" class="action-btn primary">
              <span class="icon">➕</span>
              Add New Product
            </a>
            <a routerLink="/admin/categories/new" class="action-btn">
              <span class="icon">📁</span>
              Add Category
            </a>
            <a routerLink="/admin/orders" class="action-btn">
              <span class="icon">📋</span>
              Manage Orders
            </a>
            <a routerLink="/admin/users" class="action-btn">
              <span class="icon">👥</span>
              Manage Users
            </a>
          </div>
        </div>
      </div>

      <div class="dashboard-content">
        <div class="content-section">
          <h2>Recent Orders</h2>
          <div class="orders-list" *ngIf="summary.recentOrders.length > 0; else noOrders">
            <div class="order-item" *ngFor="let order of summary.recentOrders">
              <div class="order-info">
                <span class="order-id">#{{ order.id }}</span>
                <span class="order-customer">{{ order.customerName }}</span>
              </div>
              <div class="order-details">
                <span class="order-amount">\${{ order.total | number:'1.2-2' }}</span>
                <span class="order-status" [ngClass]="'status-' + order.status.toLowerCase()">
                  {{ order.status }}
                </span>
              </div>
            </div>
          </div>
          <ng-template #noOrders>
            <p class="no-data">No recent orders</p>
          </ng-template>
        </div>

        <div class="content-section">
          <h2>Top Products</h2>
          <div class="products-list" *ngIf="summary.topProducts.length > 0; else noProducts">
            <div class="product-item" *ngFor="let product of summary.topProducts">
              <div class="product-info">
                <span class="product-name">{{ product.name }}</span>
                <span class="product-category">{{ product.category }}</span>
              </div>
              <div class="product-stats">
                <span class="product-sales">{{ product.sales }} sold</span>
                <span class="product-price">\${{ product.price | number:'1.2-2' }}</span>
              </div>
            </div>
          </div>
          <ng-template #noProducts>
            <p class="no-data">No product data available</p>
          </ng-template>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .admin-dashboard {
      padding: 2rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .dashboard-header {
      margin-bottom: 2rem;
    }

    .dashboard-header h1 {
      margin: 0 0 0.5rem 0;
      color: #333;
    }

    .dashboard-header p {
      margin: 0;
      color: #666;
    }

    .metrics-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1.5rem;
      margin-bottom: 3rem;
    }

    .metric-card {
      background: white;
      border-radius: 8px;
      padding: 1.5rem;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .metric-card.sales {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .metric-icon {
      font-size: 2rem;
    }

    .metric-content h3 {
      margin: 0 0 0.25rem 0;
      font-size: 1.8rem;
      font-weight: bold;
    }

    .metric-content p {
      margin: 0;
      opacity: 0.8;
      font-size: 0.9rem;
    }

    .dashboard-actions {
      margin-bottom: 3rem;
    }

    .action-section h2 {
      margin-bottom: 1rem;
      color: #333;
    }

    .action-buttons {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }

    .action-btn {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.75rem 1.5rem;
      background: white;
      border: 2px solid #e1e5e9;
      border-radius: 6px;
      text-decoration: none;
      color: #333;
      font-weight: 500;
      transition: all 0.2s;
    }

    .action-btn:hover {
      border-color: #007bff;
      background: #f8f9fa;
    }

    .action-btn.primary {
      background: #007bff;
      color: white;
      border-color: #007bff;
    }

    .action-btn.primary:hover {
      background: #0056b3;
    }

    .dashboard-content {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
    }

    @media (max-width: 768px) {
      .dashboard-content {
        grid-template-columns: 1fr;
      }
    }

    .content-section {
      background: white;
      border-radius: 8px;
      padding: 1.5rem;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .content-section h2 {
      margin: 0 0 1rem 0;
      color: #333;
      font-size: 1.2rem;
    }

    .order-item, .product-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.75rem 0;
      border-bottom: 1px solid #eee;
    }

    .order-item:last-child, .product-item:last-child {
      border-bottom: none;
    }

    .order-info, .product-info {
      display: flex;
      flex-direction: column;
      gap: 0.25rem;
    }

    .order-id, .product-name {
      font-weight: 500;
      color: #333;
    }

    .order-customer, .product-category {
      font-size: 0.85rem;
      color: #666;
    }

    .order-details, .product-stats {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 0.25rem;
    }

    .order-amount, .product-price {
      font-weight: 500;
      color: #333;
    }

    .order-status {
      font-size: 0.75rem;
      padding: 0.25rem 0.5rem;
      border-radius: 12px;
      text-transform: uppercase;
      font-weight: 500;
    }

    .status-processing {
      background: #fff3cd;
      color: #856404;
    }

    .status-shipped {
      background: #d1ecf1;
      color: #0c5460;
    }

    .status-delivered {
      background: #d4edda;
      color: #155724;
    }

    .product-sales {
      font-size: 0.85rem;
      color: #666;
    }

    .no-data {
      color: #666;
      font-style: italic;
      text-align: center;
      margin: 2rem 0;
    }
  `]
})
export class AdminDashboardComponent implements OnInit {
  summary: AdminSummary = {
    totalUsers: 0,
    totalOrders: 0,
    totalProducts: 0,
    totalCategories: 0,
    totalSales: 0,
    recentOrders: [],
    topProducts: []
  };

  ngOnInit() {
    this.loadAdminSummary();
  }

  private loadAdminSummary() {
    // Mock data - replace with actual API call
    this.summary = {
      totalUsers: 1247,
      totalOrders: 856,
      totalProducts: 342,
      totalCategories: 24,
      totalSales: 125430.50,
      recentOrders: [
        { id: '1001', customerName: 'John Doe', total: 89.99, status: 'Processing' },
        { id: '1002', customerName: 'Jane Smith', total: 156.50, status: 'Shipped' },
        { id: '1003', customerName: 'Bob Johnson', total: 234.75, status: 'Delivered' },
        { id: '1004', customerName: 'Alice Brown', total: 67.25, status: 'Processing' },
        { id: '1005', customerName: 'Charlie Wilson', total: 198.00, status: 'Shipped' }
      ],
      topProducts: [
        { name: 'Wireless Headphones', category: 'Electronics', sales: 89, price: 199.99 },
        { name: 'Running Shoes', category: 'Sports', sales: 76, price: 129.99 },
        { name: 'Coffee Maker', category: 'Home', sales: 64, price: 89.99 },
        { name: 'Smartphone Case', category: 'Electronics', sales: 58, price: 24.99 },
        { name: 'Yoga Mat', category: 'Sports', sales: 52, price: 39.99 }
      ]
    };
  }
}