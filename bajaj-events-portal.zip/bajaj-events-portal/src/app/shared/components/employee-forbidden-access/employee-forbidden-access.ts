import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-forbidden-access',
  standalone: true,
  imports: [],
  templateUrl: './employee-forbidden-access.html',
  styleUrl: './employee-forbidden-access.css',
})
export class EmployeeForbiddenAccess {}
