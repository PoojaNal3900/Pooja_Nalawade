export interface CudResponse {
    acknowledgement?: boolean;
    acknowledged?: boolean;
}
