import { inject } from '@angular/core';
import { CanActivateFn, Router, RouterStateSnapshot } from '@angular/router';

const ensureAccess = (state: RouterStateSnapshot, requiredRole?: string): boolean => {
  const router = inject(Router);
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');
  const employeeId = localStorage.getItem('employeeId');


  if (!token && !employeeId) {
    router.navigate(['/auth', 'login'], {
      queryParams: {
        returnUrl: state.url,
      },
    });
    return false;
  }

  // If a role is required, enforce it
  if (requiredRole) {
    // For real tokens, check the role matches
    if (token && token !== 'employee-session') {
      if (role?.toLowerCase() !== requiredRole.toLowerCase()) {
        router.navigate(['/forbidden']);
        return false;
      }
    } 
    // For employee-session or employeeId, only allow 'employee' role routes
    else if (token === 'employee-session' || employeeId) {
      if (requiredRole.toLowerCase() !== 'employee') {
        router.navigate(['/forbidden']);
        return false;
      }
    }
  }

  return true;
};

export const authGuard: CanActivateFn = (route, state) =>
  ensureAccess(state, route.data?.['role'] as string | undefined);

export const hrGuard: CanActivateFn = (_, state) => ensureAccess(state, 'hr');
