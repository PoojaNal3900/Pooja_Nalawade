import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, switchMap, throwError } from 'rxjs';
import { SecurityApi } from '../../features/security/services/security-api';

export const tokenInterceptor: HttpInterceptorFn = (req, next) => {
  if (req.url.includes('/users')) {
    return next(req);
  }

  const securityApi = inject(SecurityApi);
  const token = securityApi.getToken();
  const employeeId = localStorage.getItem('employeeId');

  let headers = req.headers.set('Content-Type', 'application/json');

  if (token && token !== 'employee-session') {
    headers = headers.set('bajaj-authorization-token', token);
  } else if (employeeId) {
    headers = headers.set('employee-id', employeeId);
  }

  const modifiedRequest = req.clone({
    headers,
  });

  return next(modifiedRequest).pipe(
    catchError((error) => {
      if (
        error instanceof HttpErrorResponse &&
        error.status === 401 &&
        token &&
        token !== 'employee-session'
      ) {
        return securityApi.refreshToken().pipe(
          switchMap(() => {
            const refreshedToken = securityApi.getToken();
            if (!refreshedToken || refreshedToken === 'employee-session') {
              securityApi.logout();
              return throwError(() => error);
            }

            let retryHeaders = req.headers.set('Content-Type', 'application/json');
            retryHeaders = retryHeaders.set('bajaj-authorization-token', refreshedToken);
            if (employeeId && !retryHeaders.has('employee-id')) {
              retryHeaders = retryHeaders.set('employee-id', employeeId);
            }

            const retryRequest = req.clone({
              headers: retryHeaders,
            });

            return next(retryRequest);
          }),
          catchError((refreshError) => {
            securityApi.logout();
            return throwError(() => refreshError);
          })
        );
      }

      return throwError(() => error);
    })
  );
};
