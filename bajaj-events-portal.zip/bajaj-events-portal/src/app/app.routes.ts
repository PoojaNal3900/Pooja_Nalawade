import { Routes } from '@angular/router';

import { EpHome } from './features/home/ep-home/ep-home';
import { EventsList } from './features/events/components/events-list/events-list';
import { EmployeesList } from './features/employees/components/employees-list/employees-list';
import { ResourceNotFound } from './shared/components/resource-not-found/resource-not-found';
import { Login } from './features/security/components/login/login';

import { authGuard, hrGuard } from './core/guards/auth-guard';
import { eventRoutes } from './features/events/events.routes';
import { employeesRoutes } from './features/employees/employees.routes';
import { securityRoutes } from './features/security/security.routes';

export const routes: Routes = [
  {
    path: '',
    component: EpHome,
    title: 'Bajaj EpHome',
  },
  {
    path: 'home',
    component: EpHome,
    title: 'Bajaj Ep Home',
  },
 {
  path:'employees',
  children:[
    ...employeesRoutes
  ]

 },
  {
    path: 'auth',
    children:[
      ...securityRoutes
    ]
  },
  
  {
    path: 'forbidden',
    loadComponent: () =>
      import('./shared/components/employee-forbidden-access/employee-forbidden-access').then(
        (c) => c.EmployeeForbiddenAccess
      ),
    title: 'Forbidden Access',
  },
  {
    path: 'events',
    children:[
      ...eventRoutes
    ]
  },
  {
    path: '**',
    component: ResourceNotFound,
    title: 'Not Found -404',
  }
];
