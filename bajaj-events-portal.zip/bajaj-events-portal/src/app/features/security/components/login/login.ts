import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { take } from 'rxjs';
import { EmployeesApi } from '../../../employees/services/employees-api';
import { AuthRequest } from '../../models/auth-request';
import { AuthResponse } from '../../models/auth-response';
import { SecurityApi } from '../../services/security-api';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {
  protected user: AuthRequest = new AuthRequest();
  protected authResponse: AuthResponse;
  private _securityApi = inject(SecurityApi);
  private _employeesApi = inject(EmployeesApi);
  protected authErrorMessage?: string = '';
  private _router = inject(Router);

  private _activatedRoute = inject(ActivatedRoute);
  private _returnUrl: string;

  ngOnInit(): void {
    this._returnUrl = this._activatedRoute.snapshot.queryParams['returnUrl'];
    const registeredEmail = this._activatedRoute.snapshot.queryParams['email'];
    if (registeredEmail) {
      this.user.email = registeredEmail;
    }
  }

  protected onCredentialSubmit(): void {
    const email = this.user.email?.trim().toLowerCase();
    if (!email) {
      this.authErrorMessage = 'Email is required to login.';
      setTimeout(() => {
        this.authErrorMessage = '';
      }, 5000);
      return;
    }

    if (this.user.password) {
      this._securityApi.authenticateCredentials(this.user).subscribe({
        next: (response) => this.handleAuthResponse(response),
      });
      return;
    }

    this._employeesApi
      .getEmployeeByEmail(email)
      .pipe(take(1))
      .subscribe({
        next: (employee) => {
          if (!employee) {
            this.authErrorMessage = 'No employee found with the provided email.';
            setTimeout(() => {
              this.authErrorMessage = '';
            }, 5000);
            return;
          }

          localStorage.setItem('token', 'employee-session');
          localStorage.setItem('refreshToken', 'employee-session');
          localStorage.setItem('role', 'employee');
          localStorage.setItem('email', employee.email);

          if (this._returnUrl) {
            this._router.navigate([this._returnUrl]);
          } else {
            this._router.navigate(['/home']);
          }
        },
      });
  }

  private handleAuthResponse(response: AuthResponse): void {
    if (response.token) {
      if (this._returnUrl) {
        this._router.navigate([this._returnUrl]);
      } else {
        this._router.navigate(['/home']);
      }
    } else {
      this.authErrorMessage = response.message;
      setTimeout(() => {
        this.authErrorMessage = '';
      }, 5000);
    }
  }
}
