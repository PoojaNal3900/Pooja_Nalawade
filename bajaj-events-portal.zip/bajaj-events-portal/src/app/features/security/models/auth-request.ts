export class AuthRequest {
  email: string;
  password: string;
}
