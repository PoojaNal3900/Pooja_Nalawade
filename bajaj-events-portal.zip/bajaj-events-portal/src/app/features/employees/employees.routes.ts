import { Routes } from '@angular/router';
import { authGuard, hrGuard } from '../../core/guards/auth-guard';
import { EmployeesList } from './components/employees-list/employees-list';

export const employeesRoutes: Routes = [
  {
    path: '',
    component: EmployeesList,
    title: 'Employees List',
    canActivate: [authGuard],
  },
  {
    path: 'register-employee',
    loadComponent: () =>
      import('../components/register-employee/register-employee').then((component) => component.RegisterEmployee),
    title: 'Register Employee',
    canActivate: [hrGuard],
  },
];
 