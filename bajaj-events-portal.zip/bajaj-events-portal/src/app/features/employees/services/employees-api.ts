import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Employee } from '../models/employee';

@Injectable({
  providedIn: 'root',
})
export class EmployeesApi {
  private _baseUrl: string = 'http://192.168.1.16:9090/api';
  private _httpClient = inject(HttpClient);
  public getAllEmployees(): Observable<Employee[]> {
    return this._httpClient.get<Employee[]>(`${this._baseUrl}/employees`);
  }

  public getEmployeeDetails(employeeId: number): Observable<Employee> {
    return this._httpClient.get<Employee>(`${this._baseUrl}/employees/${employeeId}`);
  }

  public registerEmployee(employee: Partial<Employee>): Observable<Employee> {
    return this._httpClient.post<Employee>(`${this._baseUrl}/employees`, employee);
  }

  public getEmployeeByEmail(email: string): Observable<Employee | null> {
    return this.getAllEmployees().pipe(
      map((employees) =>
        employees.find((employee) => employee.email.toLowerCase() === email.toLowerCase()) ?? null
      )
    );
  }
}
