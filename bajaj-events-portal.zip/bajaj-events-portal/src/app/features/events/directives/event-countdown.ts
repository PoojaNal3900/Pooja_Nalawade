import { Directive } from '@angular/core';

@Directive({
  selector: '[appEventCountdown]'
})
export class EventCountdown {

  constructor() { }

}
