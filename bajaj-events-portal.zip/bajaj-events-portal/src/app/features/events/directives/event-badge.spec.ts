import { EventBadge } from './event-badge';

describe('EventBadge', () => {
  it('should create an instance', () => {
    const directive = new EventBadge();
    expect(directive).toBeTruthy();
  });
});
