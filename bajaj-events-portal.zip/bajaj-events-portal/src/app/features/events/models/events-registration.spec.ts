import { EventRegistration } from './events-registration';

describe('EventRegistration', () => {
  it('should create an instance', () => {
    expect(new EventRegistration()).toBeTruthy();
  });
});
