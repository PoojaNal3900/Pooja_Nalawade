import { Routes } from '@angular/router';
import { authGuard, hrGuard } from '../../core/guards/auth-guard';
import { EventsList } from './components/events-list/events-list';

export const eventRoutes: Routes = [
  {
    path: '',
    component: EventsList,
    title: 'Events List',
    canActivate: [authGuard],
  },
  {
    path: 'register-event',
    loadComponent: () =>
      import('../components/register-event/register-event').then((component) => component.RegisterEvent),
    title: 'Register for an event',
    canActivate: [hrGuard],
  },
  {
    path: ':id',
    loadComponent: () =>
      import('./components/event-details/event-details').then((component) => component.EventDetails),
    title: 'Event Details',
    data: { companyName: 'Bajaj Pvt. Ltd', role: 'Employee' },
    canActivate: [authGuard],
  },
];
