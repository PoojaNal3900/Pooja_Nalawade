import { Component, OnDestroy, inject } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { EventRegistration } from '../../events/models/events-registration';

import { Subscription } from 'rxjs';

import { EventsApi } from '../../events/services/events-api';
 


@Component({
  selector: 'app-register-event',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './register-event.html',
  styleUrl: './register-event.css',
})
export class RegisterEvent implements OnDestroy {
  private _eventsApi = inject(EventsApi);
  private _router = inject(Router);
  private _eventsubscription: Subscription | null = null;
  protected title : string = "Register new Bajaj Event";
  protected register: EventRegistration = new EventRegistration();

  protected onEventSubmit(): void {
    this._eventsubscription = this._eventsApi.schedulenewevent(this.register.eventForm.value).subscribe({
      next: data => {
        const isAcknowledged = data?.acknowledgement === true || data?.acknowledged === true;
        if (isAcknowledged) {
          this._router.navigate(['/events']);
        }
      }
    });
  }
  ngOnDestroy(): void {
    if (this._eventsubscription) {
      this._eventsubscription.unsubscribe();
      this._eventsubscription = null;
    }
  }
}
