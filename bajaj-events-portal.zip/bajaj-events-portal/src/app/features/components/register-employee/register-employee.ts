import { Component, OnDestroy, inject } from '@angular/core';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { Employee } from '../../employees/models/employee';
import { EmployeesApi } from '../../employees/services/employees-api';

const    employeeNameValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // Name should contain only letters and spaces, min 3 chars
  return /^[a-zA-Z\s]{3,}$/.test(value) ? null : { invalidName: true };
};

const phoneNumberValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // Phone should be 10 digits
  return /^[6-9]\d{9}$/.test(value) ? null : { invalidPhone: true };
};

const employeeIdValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // Employee ID should be a positive number, 4-10 digits
  return /^[1-9]\d{3,9}$/.test(value) ? null : { invalidEmployeeId: true };
};

const zipcodeValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  return /^\d{5,6}$/.test(value) ? null : { invalidZipcode: true };
};

const cityValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // City should contain only letters, spaces, and hyphens, min 2 chars
  return /^[a-zA-Z\s\-]{2,}$/.test(value) ? null : { invalidCity: true };
};

const joiningDateValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  if (!control.value) {
    return null;
  }
  const selectedDate = new Date(control.value);
  const today = new Date();
  const minDate = new Date('1950-01-01');
  
  today.setHours(0, 0, 0, 0);
  selectedDate.setHours(0, 0, 0, 0);
  
  if (selectedDate > today) {
    return { futureJoiningDate: true };
  }
  if (selectedDate < minDate) {
    return { invalidJoiningDate: true };
  }
  return null;
};

const addressValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // Address should be alphanumeric with spaces, commas, hyphens, min 10 chars
  return /^[a-zA-Z0-9\s,.\-]{10,}$/.test(value) ? null : { invalidAddress: true };
};

const skillSetsValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // Skills should be alphanumeric with spaces, commas, min 3 chars
  return /^[a-zA-Z0-9\s,.\-+#]{3,}$/.test(value) ? null : { invalidSkills: true };
};

const countryValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // Country should contain only letters and spaces, min 2 chars
  return /^[a-zA-Z\s]{2,}$/.test(value) ? null : { invalidCountry: true };
};

const avatarUrlValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const value = control.value?.toString().trim();
  if (!value) {
    return null;
  }
  // Basic URL validation
  const urlPattern = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
  return urlPattern.test(value) ? null : { invalidUrl: true };
};

@Component({
  selector: 'app-register-employee',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './register-employee.html',
  styleUrl: './register-employee.css',
})
export class RegisterEmployee implements OnDestroy {
  private formBuilder = inject(FormBuilder);
  private employeesApi = inject(EmployeesApi);
  private router = inject(Router);
  private employeeSubscription: Subscription | null = null;

  protected title: string = 'Register Employee';
  protected employeeForm = this.formBuilder.group({
    employeeName: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(3), employeeNameValidator],
    }),
    city: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, cityValidator],
    }),
    email: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, Validators.email],
    }),
    phone: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, phoneNumberValidator],
    }),
    employeeId: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, employeeIdValidator],
    }),
    address: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(10), addressValidator],
    }),
    zipcode: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, zipcodeValidator],
    }),
    skillSets: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(3), skillSetsValidator],
    }),
    country: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, Validators.minLength(2), countryValidator],
    }),
    joiningDate: this.formBuilder.control('', {
      nonNullable: true,
      validators: [Validators.required, joiningDateValidator],
    }),
  });

  protected onEmployeeSubmit(): void {
    if (this.employeeForm.invalid) {
      this.employeeForm.markAllAsTouched();
      return;
    }

    const rawValue = this.employeeForm.getRawValue();
    const employeePayload: Partial<Employee> = {
      employeeName: rawValue.employeeName.trim(),
      city: rawValue.city.trim(),
      email: rawValue.email.trim().toLowerCase(),
      phone: rawValue.phone ? Number(rawValue.phone) : undefined,
      employeeId: rawValue.employeeId ? Number(rawValue.employeeId) : undefined,
      address: rawValue.address.trim(),
      zipcode: rawValue.zipcode ? Number(rawValue.zipcode) : undefined,
      skillSets: rawValue.skillSets.trim(),
      country: rawValue.country.trim(),
      joiningDate: rawValue.joiningDate ? new Date(rawValue.joiningDate) : undefined,
    };

    this.employeeSubscription = this.employeesApi.registerEmployee(employeePayload).subscribe({
      next: () => {
        // Navigate to the event list page after successful registration
        this.router.navigate(['/events']);
      },
    });
  }

  ngOnDestroy(): void {
    if (this.employeeSubscription) {
      this.employeeSubscription.unsubscribe();
      this.employeeSubscription = null;
    }
  }
}
